<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Invoice;
use App\Services\NotificationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Http;

class PaymentController extends Controller
{
    public function __construct(protected NotificationService $notifications) {}

    /**
     * Get all payments with totals (Admin and Attendant)
     */
    public function index(Request $request)
    {
        if (!in_array($request->user()->role, ['admin', 'attendant'], true)) {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $perPage = $request->input('per_page', 15);

        $invoiceQuery = Invoice::when($request->filled('search'), function ($query) use ($request) {
                $query->whereHas('order', function ($q) use ($request) {
                    $q->where('order_number', 'like', '%' . $request->search . '%')
                      ->orWhere('customer_name', 'like', '%' . $request->search . '%')
                      ->orWhere('customer_email', 'like', '%' . $request->search . '%')
                      ->orWhere('customer_phone', 'like', '%' . $request->search . '%');
                });
            })
            ->when($request->filled('outlet_id'), fn($q) => $q->whereHas('order', fn($q) => $q->where('outlet_id', $request->outlet_id)))
            ->when($request->filled('payment_status'), fn($q) => $q->where('payment_status', $request->payment_status))
            ->when($request->filled('payment_method'), fn($q) => $q->where('payment_method', $request->payment_method));

        // Calculate totals on the full filtered dataset
        $totalRevenue = (clone $invoiceQuery)->where('payment_status', 'paid')->sum('amount');
        $totalPending = (clone $invoiceQuery)->whereIn('payment_status', ['pending', 'unpaid'])->count();
        $totalCompleted = (clone $invoiceQuery)->where('payment_status', 'paid')->count();
        $totalTransactions = (clone $invoiceQuery)->count();

        // Get paginated payments
        $payments = $invoiceQuery->with(['order.user', 'order.attendant'])
            ->latest()
            ->paginate($perPage);

        return response()->json([
            'totals' => [
                'total_revenue' => $totalRevenue,
                'total_pending' => $totalPending,
                'total_completed' => $totalCompleted,
                'total_transactions' => $totalTransactions
            ],
            'payments' => $payments
        ]);
    }

    /**
     * Initialize payment - returns Paystack authorization URL
     */
    public function initializePayment(Request $request)
    {
        $validated = $request->validate([
            'customer_email' => 'required|email',
            'amount' => 'required|numeric|min:0',
            'callback_url' => 'nullable|url',
            'discount_code' => 'nullable|string'
        ]);

        $finalAmount = $validated['amount'];
        $discountAmount = 0;
        $discountCode = null;

        if (!empty($validated['discount_code'])) {
            $discount = \App\Models\Discount::where('code', strtoupper($validated['discount_code']))->first();

            if ($discount && $discount->isValid()) {
                $discountAmount = $discount->calculateDiscount($validated['amount']);
                $finalAmount = max(0, $validated['amount'] - $discountAmount);
                $discountCode = $discount->code;
            }
        }

        $paymentGateway = app(\App\Interfaces\PaymentGatewayInterface::class);

        $result = $paymentGateway->charge(
            $finalAmount,
            $validated['customer_email'],
            ['callback_url' => $validated['callback_url'] ?? null]
        );

        $result['discount_applied'] = $discountCode;
        $result['discount_amount'] = $discountAmount;
        $result['original_amount'] = $validated['amount'];
        $result['final_amount'] = $finalAmount;

        return response()->json($result);
    }

    /**
     * Verify payment after redirect
     */
    public function verifyPayment(Request $request)
    {
        $reference = $request->query('reference');

        if (!$reference) {
            return response()->json(['message' => 'No reference provided'], 400);
        }

        $paymentGateway = app(\App\Interfaces\PaymentGatewayInterface::class);
        $result = $paymentGateway->verifyTransaction($reference);

        return response()->json($result);
    }

    /**
     * Get order status after payment (callback endpoint)
     * Accepts: ?reference=  OR  ?order_id=  OR  ?order_number=
     */
    public function orderStatus(Request $request)
    {
        $order = null;

        if ($request->filled('reference')) {
            $reference = $request->query('reference');
            $order = Order::where('paystack_reference', $reference)
                ->orWhereRaw('UPPER(order_number) = ?', [strtoupper($reference)])
                ->with(['orderItems.menu', 'invoice'])
                ->first();
        } elseif ($request->filled('order_id')) {
            $order = Order::with(['orderItems.menu', 'invoice'])->find($request->query('order_id'));
        } elseif ($request->filled('order_number')) {
            $order = Order::whereRaw('UPPER(order_number) = ?', [strtoupper($request->query('order_number'))])
                ->with(['orderItems.menu', 'invoice'])
                ->first();
        }

        if (!$order) {
            return response()->json(['message' => 'Order not found'], 404);
        }

        // If still pending or init_payment, verify with Paystack (handles webhook delays)
        if ($order->status === 'pending' || $order->status === 'init_payment') {
            $paymentGateway = app(\App\Interfaces\PaymentGatewayInterface::class);
            $verifyRef = $order->paystack_reference;
            $verificationResult = ['status' => 'failed'];

            if ($verifyRef) {
                // Try direct transaction verify first (works for gateway + numeric terminal refs)
                $verificationResult = $paymentGateway->verifyTransaction($verifyRef);

                // If failed and it looks like an offline_reference (pure numeric), try fetching
                // the payment request by request_code to get the real transaction reference
                if ($verificationResult['status'] === 'failed' && is_numeric($verifyRef)) {
                    $prVerify = Http::withToken(config('services.paystack.secret_key'))
                        ->get("https://api.paystack.co/paymentrequest", ['perPage' => 10]);

                    if ($prVerify->successful()) {
                        foreach ($prVerify->json('data') ?? [] as $pr) {
                            if ((string)($pr['offline_reference'] ?? '') === (string)$verifyRef) {
                                $txRef = $pr['transactions'][0]['reference'] ?? null;
                                if ($txRef) {
                                    $verificationResult = $paymentGateway->verifyTransaction($txRef);
                                    // Store the real reference for future lookups
                                    if ($verificationResult['status'] === 'success') {
                                        $order->update(['paystack_reference' => $txRef]);
                                    }
                                }
                                break;
                            }
                        }
                    }
                }
            }

            if ($verificationResult['status'] === 'success') {
                $order->update(['status' => 'confirmed']);
                $order->invoice()->update(['payment_status' => 'paid']);
                $order->deductItemsStock();
                $statusUser = $order->user_id ? \App\Models\User::find($order->user_id) : null;
                if (! $statusUser || $statusUser->shouldReceiveOrderEmails()) {
                    Mail::to($order->customer_email)->send(new \App\Mail\OrderPlaced($order));
                }
                $this->notifications->orderPlaced($order);
                $order->refresh();
                $order->load(['orderItems.menu', 'invoice']);
                Log::info("Order {$order->order_number} payment confirmed via status check");
            }
        }

        return response()->json([
            'order' => $order,
            'payment_status' => $order->invoice->payment_status,
            'order_status' => $order->status
        ]);
    }

    /**
     * Payment callback endpoint (redirects to frontend receipt page)
     */
    public function paymentCallback(Request $request)
    {
        $reference = $request->query('reference') ?: $request->query('trxref');

        if (!$reference) {
            return redirect(config('services.frontend_url'));
        }

        $order = Order::where('paystack_reference', $reference)
            ->orWhereRaw('UPPER(order_number) = ?', [strtoupper($reference)])
            ->first();

        if (!$order) {
            return redirect(config('services.frontend_url'));
        }

        // If still pending or init_payment, verify with Paystack
        if ($order->status === 'pending' || $order->status === 'init_payment') {
            $paymentGateway = app(\App\Interfaces\PaymentGatewayInterface::class);
            $verifyRef = $order->paystack_reference;
            $verificationResult = $verifyRef ? $paymentGateway->verifyTransaction($verifyRef) : ['status' => 'failed'];

            if ($verificationResult['status'] === 'success') {
                $order->update(['status' => 'confirmed']);
                $order->invoice()->update(['payment_status' => 'paid']);
                $order->deductItemsStock();
                $callbackUser = $order->user_id ? \App\Models\User::find($order->user_id) : null;
                if (! $callbackUser || $callbackUser->shouldReceiveOrderEmails()) {
                    Mail::to($order->customer_email)->send(new \App\Mail\OrderPlaced($order));
                }
                $this->notifications->orderPlaced($order);
                Log::info("Order {$order->order_number} payment confirmed via callback");
            }
        }

        return redirect(config('services.frontend_url') . '/receipt/' . $order->id);
    }

    /**
     * Paystack webhook handler
     */
    public function webhook(Request $request)
    {
        // Log webhook received for debugging
        Log::info('Webhook received', [
            'headers' => $request->headers->all(),
            'body' => $request->all()
        ]);

        // Verify webhook signature
        $signature = $request->header('x-paystack-signature');
        $body = $request->getContent();

        if (!$signature || hash_hmac('sha512', $body, config('services.paystack.secret_key')) !== $signature) {
            Log::warning('Invalid Paystack webhook signature');
            return response()->json(['message' => 'Invalid signature'], 400);
        }

        $event = $request->input('event');
        $data = $request->input('data');

        Log::info('Webhook event processed', [
            'event'     => $event,
            'reference' => $data['reference'] ?? 'N/A',
            'metadata'  => $data['metadata'] ?? null,
            'full_data' => $data,
        ]);

        if ($event === 'charge.success') {
            $reference        = $data['reference'] ?? null;
            $status           = $data['status'] ?? null;
            $offlineReference = $data['metadata']['offline_reference'] ?? null;

            if (! $reference || $status !== 'success') {
                return response()->json(['message' => 'Webhook received'], 200);
            }

            $order = Order::where('paystack_reference', $reference)->first()
                ?? ($offlineReference ? Order::where('paystack_reference', $offlineReference)->first() : null)
                ?? Order::whereRaw('UPPER(order_number) = ?', [strtoupper($reference)])->first();

            if ($order && ($order->status === 'pending' || $order->status === 'init_payment')) {
                $finalStatus = match ($order->post_payment_action) {
                    'send_to_kitchen' => 'in_kitchen',
                    'complete'        => 'completed',
                    default           => 'confirmed',
                };
                $updateData = ['status' => $finalStatus, 'paystack_reference' => $reference];
                if ($finalStatus === 'in_kitchen') {
                    $updateData['sent_to_kitchen_at'] = now();
                } elseif ($finalStatus === 'completed') {
                    $updateData['completed_at'] = now();
                }
                $order->update($updateData);
                $order->invoice()->update(['payment_status' => 'paid']);
                $order->deductItemsStock();
                $webhookUser = $order->user_id ? \App\Models\User::find($order->user_id) : null;
                if (! $webhookUser || $webhookUser->shouldReceiveOrderEmails()) {
                    Mail::to($order->customer_email)->send(new \App\Mail\OrderPlaced($order));
                }
                $this->notifications->orderPlaced($order);
                Log::info("Order {$order->order_number} set to {$finalStatus} via charge.success webhook");
            } else {
                Log::warning('Webhook charge.success: order not found or already confirmed', ['reference' => $reference]);
            }
        }

        // POS terminal payments fire paymentrequest.success with offline_reference at top level
        if ($event === 'paymentrequest.success') {
            $offlineReference = $data['offline_reference'] ?? null;
            $status           = $data['status'] ?? null;

            if (! $offlineReference || $status !== 'success') {
                return response()->json(['message' => 'Webhook received'], 200);
            }

            $order = Order::where('paystack_reference', $offlineReference)->first();

            if ($order && ($order->status === 'pending' || $order->status === 'init_payment')) {
                $finalStatus = match ($order->post_payment_action) {
                    'send_to_kitchen' => 'in_kitchen',
                    'complete'        => 'completed',
                    default           => 'confirmed',
                };
                $updateData = ['status' => $finalStatus];
                if ($finalStatus === 'in_kitchen') {
                    $updateData['sent_to_kitchen_at'] = now();
                } elseif ($finalStatus === 'completed') {
                    $updateData['completed_at'] = now();
                }
                $order->update($updateData);
                $order->invoice()->update(['payment_status' => 'paid']);
                $order->deductItemsStock();
                $webhookUser = $order->user_id ? \App\Models\User::find($order->user_id) : null;
                if (! $webhookUser || $webhookUser->shouldReceiveOrderEmails()) {
                    Mail::to($order->customer_email)->send(new \App\Mail\OrderPlaced($order));
                }
                $this->notifications->orderPlaced($order);
                Log::info("Order {$order->order_number} set to {$finalStatus} via paymentrequest.success webhook");
            } else {
                Log::warning('Webhook paymentrequest.success: order not found or already confirmed', ['offline_reference' => $offlineReference]);
            }
        }

        return response()->json(['message' => 'Webhook received'], 200);
    }
}
