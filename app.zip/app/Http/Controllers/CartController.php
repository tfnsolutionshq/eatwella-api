<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Menu;
use App\Models\Setting;
use App\Models\Tax;
use Illuminate\Http\Request;

class CartController extends Controller
{
    protected function getCartId(Request $request)
    {
        if ($request->user()) {
            return null;
        }
        return $request->header('X-Cart-ID');
    }

    private function applyInclusivePriceToCart($cart)
    {
        $mode = Setting::where('key', 'tax_mode')->value('value') ?? 'exclusive';
        if ($mode !== 'inclusive') return $cart;

        $rate = Tax::where('is_active', true)->sum('rate');
        $multiplier = 1 + ((float) $rate / 100);

        foreach ($cart->items as $item) {
            if ($item->menu) {
                $item->menu->price = round((float) $item->menu->price * $multiplier, 2);
            }
        }

        return $cart;
    }

    /**
     * Get the current cart content.
     */
    public function index(Request $request)
    {
        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::with(['items.menu', 'items.packaging'])->where('user_id', $user->id)->first();
        } else {
            $cartId = $request->header('X-Cart-ID');
            if (!$cartId) {
                return response()->json(['items' => []]);
            }
            $cart = Cart::with(['items.menu', 'items.packaging'])->where('session_id', $cartId)->first();
        }

        if (!$cart) {
            return response()->json(['items' => []]);
        }

        return response()->json($this->applyInclusivePriceToCart($cart));
    }

    /**
     * Add item to cart.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'menu_id'      => 'required|exists:menus,id',
            'quantity'     => 'required|integer|min:1',
            'packaging_id' => 'nullable|exists:takeaway_packagings,id',
            'outlet_id'    => 'nullable|uuid|exists:outlets,id',
        ]);

        $menu = Menu::findOrFail($validated['menu_id']);
        if (!$menu->is_available) {
            return response()->json(['message' => 'Menu unavailable'], 422);
        }

        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::firstOrCreate(['user_id' => $user->id]);
        } else {
            $cartId = $request->header('X-Cart-ID');
            if (!$cartId) {
                return response()->json(['message' => 'X-Cart-ID header required'], 400);
            }
            $cart = Cart::firstOrCreate(['session_id' => $cartId]);
        }

        $outletChanged = false;

        if (! empty($validated['outlet_id'])) {
            $newOutletId = $validated['outlet_id'];
            if ($cart->outlet_id && (string) $cart->outlet_id !== (string) $newOutletId) {
                $outletChanged = true;
            }
            $cart->outlet_id = $newOutletId;
            $cart->save();
        }

        $cartItem = $cart->items()
            ->where('menu_id', $validated['menu_id'])
            ->where('packaging_id', $validated['packaging_id'] ?? null)
            ->first();

        if ($cartItem) {
            $cartItem->quantity += $validated['quantity'];
            $cartItem->save();
        } else {
            $cart->items()->create([
                'menu_id'      => $validated['menu_id'],
                'quantity'     => $validated['quantity'],
                'packaging_id' => $validated['packaging_id'] ?? null,
            ]);
        }

        $cart->load('items.menu', 'items.packaging');
        $this->applyInclusivePriceToCart($cart);

        $data = $cart->toArray();

        return response()->json(
            $outletChanged ? array_merge($data, ['outlet_changed' => true]) : $data,
            201
        );
    }

    /**
     * Update item quantity or packaging.
     */
    public function update(Request $request, $itemId)
    {
        $validated = $request->validate([
            'quantity'     => 'sometimes|integer|min:1',
            'packaging_id' => 'sometimes|nullable|exists:takeaway_packagings,id',
            'outlet_id'    => 'sometimes|nullable|uuid|exists:outlets,id',
        ]);

        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::where('user_id', $user->id)->first();
        } else {
            $cartId = $this->getCartId($request);
            if (!$cartId) {
                return response()->json(['message' => 'X-Cart-ID header required'], 400);
            }
            $cart = Cart::where('session_id', $cartId)->first();
        }

        if (!$cart) {
            return response()->json(['message' => 'Cart not found'], 404);
        }

        $outletChanged = false;

        if (! empty($validated['outlet_id'])) {
            $newOutletId = $validated['outlet_id'];
            if ($cart->outlet_id && (string) $cart->outlet_id !== (string) $newOutletId) {
                $outletChanged = true;
            }
            $cart->outlet_id = $newOutletId;
            $cart->save();
        }

        $item = $cart->items()->where('id', $itemId)->first();

        if (!$item) {
            return response()->json(['message' => 'Item not found in cart'], 404);
        }

        $updateData = [];
        if (isset($validated['quantity'])) {
            $updateData['quantity'] = $validated['quantity'];
        }
        if (array_key_exists('packaging_id', $validated)) {
            $updateData['packaging_id'] = $validated['packaging_id'];
        }

        if (!empty($updateData)) {
            $item->update($updateData);
        }

        $cart->load('items.menu', 'items.packaging');
        $this->applyInclusivePriceToCart($cart);

        $data = $cart->toArray();

        return response()->json(
            $outletChanged ? array_merge($data, ['outlet_changed' => true]) : $data
        );
    }

    /**
     * Remove item from cart.
     */
    public function destroy(Request $request, $itemId)
    {
        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::where('user_id', $user->id)->first();
        } else {
            $cartId = $this->getCartId($request);
            if (!$cartId) {
                return response()->json(['message' => 'X-Cart-ID header required'], 400);
            }
            $cart = Cart::where('session_id', $cartId)->first();
        }

        if (!$cart) {
            return response()->json(['message' => 'Cart not found'], 404);
        }

        $item = $cart->items()->where('id', $itemId)->first();

        if (!$item) {
            return response()->json(['message' => 'Item not found in cart'], 404);
        }

        $item->delete();

        return response()->json($this->applyInclusivePriceToCart($cart->load('items.menu', 'items.packaging')));
    }


    /**
     * Apply discount code to cart.
     */
    public function applyDiscount(Request $request)
    {
        $request->validate(['code' => 'required|string']);

        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::where('user_id', $user->id)->first();
        } else {
            $cartId = $this->getCartId($request);
            if (!$cartId) {
                return response()->json(['message' => 'X-Cart-ID header required'], 400);
            }
            $cart = Cart::where('session_id', $cartId)->first();
        }

        if (!$cart) {
            return response()->json(['message' => 'Cart is empty'], 404);
        }

        $discount = \App\Models\Discount::where('code', strtoupper($request->code))
            ->where('discount_type', 'menu')
            ->first();

        if (!$discount || !$discount->isValid()) {
            return response()->json(['message' => 'Invalid or expired discount code'], 400);
        }

        $user = auth('sanctum')->user();
        if (!$discount->isForUser($user)) {
            return response()->json(['message' => 'This discount code is not valid for your account'], 403);
        }

        $cart->discount_code = $discount->code;
        $cart->save();

        return response()->json([
            'message' => 'Discount applied successfully',
            'cart' => $cart->load('items.menu'),
            'discount' => $discount
        ]);
    }

    /**
     * Remove discount from cart.
     */
    public function removeDiscount(Request $request)
    {
        $user = auth('sanctum')->user();

        if ($user) {
            $cart = Cart::where('user_id', $user->id)->first();
        } else {
            $cartId = $this->getCartId($request);
            if (!$cartId) {
                return response()->json(['message' => 'X-Cart-ID header required'], 400);
            }
            $cart = Cart::where('session_id', $cartId)->first();
        }

        if (!$cart) {
            return response()->json(['message' => 'Cart not found'], 404);
        }

        $cart->discount_code = null;
        $cart->save();

        return response()->json([
            'message' => 'Discount removed',
            'cart' => $cart->load('items.menu')
        ]);
    }

}
