<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Order;
use App\Models\FcmToken;
use App\Services\FirebaseService;
use App\Services\LoyaltyService;
use App\Services\NewUserDiscountService;
use App\Mail\WelcomeEmail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Validation\ValidationException;

class CustomerAuthController extends Controller
{
    public function register(Request $request)
    {
        $validated = $request->validate([
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|email|unique:users,email',
            'password' => 'required|string|min:6',
            'phone' => 'nullable|string|max:20',
            'zone_id' => 'nullable|exists:zones,id',
            'street_address' => 'nullable|string',
            'closest_landmark' => 'nullable|string',
            'birth_month' => 'nullable|integer|min:1|max:12',
            'birthday' => 'nullable|date',
        ]);

        $user = User::create([
            'name' => trim($validated['first_name'] . ' ' . $validated['last_name']),
            'email' => $validated['email'],
            'password' => $validated['password'],
            'phone' => $validated['phone'] ?? null,
            'birth_month' => $validated['birth_month'] ?? null,
            'birthday' => $validated['birthday'] ?? null,
            'role' => 'customer',
        ]);

        $user->addresses()->create([
            'zone_id' => $validated['zone_id'],
            'street_address' => $validated['street_address'],
            'closest_landmark' => $validated['closest_landmark'] ?? null,
        ]);

        $token = $user->createToken('customer-token')->plainTextToken;

        [$menuDiscount, $freeDeliveryDiscount] = (new NewUserDiscountService)->createForUser($user);

        Mail::to($user->email)->queue(new WelcomeEmail($user, $menuDiscount, $freeDeliveryDiscount));

        return response()->json([
            'message' => 'Account created successfully',
            'user' => $user,
            'token' => $token
        ], 201);
    }

    public function login(Request $request)
    {
        $request->validate([
            'login'       => 'required|string',
            'password'    => 'required',
            'fcm_token'   => 'nullable|string',
            'device_type' => 'nullable|in:android,ios,web',
        ]);

        $field = filter_var($request->login, FILTER_VALIDATE_EMAIL) ? 'email' : 'phone';

        $user = User::where($field, $request->login)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            throw ValidationException::withMessages([
                'login' => ['The provided credentials are incorrect.'],
            ]);
        }

        if ($user->role !== 'customer') {
            return response()->json(['message' => 'Forbidden'], 403);
        }

        $token = $user->createToken('customer-token')->plainTextToken;

        // Register FCM token if provided and send a test push
        if ($request->filled('fcm_token')) {
            FcmToken::updateOrCreate(
                ['user_id' => $user->id, 'token' => $request->fcm_token],
                ['device_type' => $request->device_type ?? null]
            );

            app(FirebaseService::class)->sendToUser(
                $user,
                '👋 Login Successful',
                'Welcome back, ' . $user->first_name . '! Push notifications are working.',
                ['type' => 'login_test']
            );
        }

        return response()->json([
            'message' => 'Login successful',
            'user'    => $user->load('addresses.zone'),
            'token'   => $token
        ]);
    }

    public function profile(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }
        return response()->json($request->user());
    }

    public function updateProfile(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }
        $validated = $request->validate([
            'first_name' => 'nullable|string|max:255',
            'last_name' => 'nullable|string|max:255',
            'phone' => 'nullable|string|max:20',
            'birth_month' => 'nullable|integer|min:1|max:12',
            'birthday' => 'nullable|date',
        ]);

        $data = array_filter([
            'name' => isset($validated['first_name']) || isset($validated['last_name'])
                ? trim(($validated['first_name'] ?? $request->user()->first_name) . ' ' . ($validated['last_name'] ?? $request->user()->last_name))
                : null,
            'phone' => $validated['phone'] ?? null,
            'birth_month' => $validated['birth_month'] ?? null,
            'birthday' => $validated['birthday'] ?? null,
        ], fn($v) => !is_null($v));

        $request->user()->update($data);

        return response()->json([
            'message' => 'Profile updated successfully',
            'user' => $request->user()
        ]);
    }

    public function overview(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }
        $user = $request->user();

        $totalOrders = Order::where('user_id', $user->id)->count();
        $totalSpent = Order::where('user_id', $user->id)
            ->whereIn('status', ['completed', 'confirmed'])
            ->sum('final_amount');

        return response()->json([
            'total_orders' => $totalOrders,
            'total_spent' => $totalSpent,
            'loyalty_points' => $user->loyalty_points ?? 0,
            'member_tier' => null
        ]);
    }

    public function activeOrders(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }

        $orders = Order::where('user_id', $request->user()->id)
            ->whereNotIn('status', ['completed', 'cancelled', 'init_payment'])
            ->withSum('orderItems as total_items', 'quantity')
            ->latest()
            ->paginate($request->get('per_page', 10), ['id', 'order_number', 'status', 'final_amount', 'user_id']);

        $orders->getCollection()->transform(fn($order) => [
            'id'           => $order->id,
            'order_number' => $order->order_number,
            'status'       => $order->status,
            'total_items'  => (int) $order->total_items,
            'total_amount' => (float) $order->final_amount,
        ]);

        return response()->json($orders);
    }



    public function recentOrders(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }
        $perPage = $request->get('per_page', 10);

        $orders = Order::where('user_id', $request->user()->id)
            ->where('status', '!=', 'init_payment')
            ->with(['orderItems.menu', 'orderItems.packaging', 'invoice', 'deliveryAgent', 'review:id,order_id,user_id,rating,comment,created_at', 'review.user:id,name'])
            ->latest()
            ->paginate($perPage);

        $orders->getCollection()->each(function ($order) {
            $order->makeVisible('delivery_pin');
            $order->setHidden(array_merge($order->getHidden(), ['deliveryAgent', 'delivery_agent']));
        });

        return response()->json($orders);
    }

    public function loyaltyInfo(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }

        $user = $request->user();
        $loyalty = app(LoyaltyService::class);

        $amount = (float) $request->query('amount', 0);

        return response()->json([
            'points_balance'      => $user->loyalty_points ?? 0,
            'points_value'        => $loyalty->pointsToNaira($user->loyalty_points ?? 0),
            'point_value'         => $loyalty->getPointValue(),
            'min_redemption'      => $loyalty->getMinRedemption(),
            'tiers'               => $loyalty->getTiers(),
            'points_for_amount'   => $amount > 0 ? $loyalty->calculatePointsForAmount($amount) : null,
            'points_needed'       => $amount > 0 ? $loyalty->nairaToPoints($amount) : null,
        ]);
    }

    public function logout(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }

        // Remove FCM token for this device so push stops after logout
        if ($request->filled('fcm_token')) {
            FcmToken::where('user_id', $request->user()->id)
                ->where('token', $request->fcm_token)
                ->delete();
        }

        $request->user()->currentAccessToken()->delete();

        return response()->json(['message' => 'Logged out successfully']);
    }

    public function changePassword(Request $request)
    {
        if ($response = $this->requireRole($request, ['customer'])) {
            return $response;
        }
        $validated = $request->validate([
            'current_password' => 'required',
            'new_password' => 'required|string|min:6',
        ]);

        if (!Hash::check($validated['current_password'], $request->user()->password)) {
            return response()->json(['message' => 'Current password is incorrect'], 422);
        }

        $request->user()->update(['password' => $validated['new_password']]);

        return response()->json(['message' => 'Password changed successfully']);
    }

    public function deleteAccount(Request $request)
    {
        $request->validate(['password' => 'required']);

        if ($request->user()) {
            // Authenticated
            if ($request->user()->role !== 'customer') {
                return response()->json(['message' => 'Forbidden'], 403);
            }

            if (! Hash::check($request->password, $request->user()->password)) {
                return response()->json(['message' => 'Password is incorrect.'], 422);
            }

            $user = $request->user();
        } else {
            // Guest — email required
            $request->validate(['email' => 'required|email']);

            $user = User::where('email', $request->email)
                        ->where('role', 'customer')
                        ->first();

            if (! $user || ! Hash::check($request->password, $user->password)) {
                return response()->json(['message' => 'Invalid credentials.'], 401);
            }
        }

        $user->tokens()->delete();
        $user->delete();

        return response()->json(['message' => 'Account deleted successfully.']);
    }
}
