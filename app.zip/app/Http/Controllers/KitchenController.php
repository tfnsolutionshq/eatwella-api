<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class KitchenController extends Controller
{
    /**
     * Get a list of confirmed orders for the kitchen to prepare.
     */
    public function getConfirmedOrders(Request $request)
    {
        if ($response = $this->requireRole($request, ['kitchen'])) {
            return $response;
        }

        $query = Order::with(['orderItems.menu', 'orderItems.packaging'])
            ->whereIn('status', ['in_kitchen', 'processing'])
            ->orderBy('sent_to_kitchen_at', 'asc');

        if ($outlet = $this->outletContext($request)) {
            $query->where('outlet_id', $outlet->id);
        }

        return response()->json($query->get());
    }

    /**
     * Mark one or more orders as preparing (processing).
     */
    public function markAsPreparing(Request $request)
    {
        if ($response = $this->requireRole($request, ['kitchen'])) {
            return $response;
        }

        $validated = $request->validate([
            'order_ids' => 'required|array',
            'order_ids.*' => 'required|uuid|exists:orders,id',
        ]);

        $query = Order::whereIn('id', $validated['order_ids'])
            ->where('status', 'in_kitchen');

        if ($outlet = $this->outletContext($request)) {
            $query->where('outlet_id', $outlet->id);
        }

        $updatedCount = $query->update(['status' => 'processing', 'preparing_at' => now()]);

        return response()->json([
            'message' => "Successfully marked {$updatedCount} order(s) as preparing.",
            'updated_count' => $updatedCount
        ]);
    }

    /**
     * Mark one or more orders as ready.
     */
    public function markAsReady(Request $request)
    {
        if ($response = $this->requireRole($request, ['kitchen'])) {
            return $response;
        }

        $validated = $request->validate([
            'order_ids' => 'required|array',
            'order_ids.*' => 'required|uuid|exists:orders,id',
        ]);

        $query = Order::whereIn('id', $validated['order_ids'])
            ->whereIn('status', ['in_kitchen', 'processing']);

        if ($outlet = $this->outletContext($request)) {
            $query->where('outlet_id', $outlet->id);
        }

        $updatedCount = $query->update(['status' => 'ready', 'ready_at' => now()]);

        return response()->json([
            'message' => "Successfully marked {$updatedCount} order(s) as ready.",
            'updated_count' => $updatedCount
        ]);
    }
}
